//
//  Book.swift
//  MobiDev
//
//  Created by Cockerman on 25.04.2021.
//

import Foundation

class Book{
    var title = ""
    var subtitle = ""
    var isbn13 = ""
    var price = ""
    var image = ""
    var authors = ""
    var publisher = ""
    var pages = ""
    var desc = ""
    var year = ""
    var rating = ""
    var added = false
    init(title: String, subtitle: String, isbn13: String, price: String, image: String){
        self.title = title
        self.subtitle = subtitle
        self.isbn13 = isbn13
        self.price = price
        self.image = image
    }
    init(){
        
    }
}
