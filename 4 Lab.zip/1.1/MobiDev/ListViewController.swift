//
//  ListViewController.swift
//  MobiDev
//
//  Created by Cockerman on 25.04.2021.
//

import UIKit


class MyCell: UITableViewCell {
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
}

class MyCellNoImage: UITableViewCell{
    @IBOutlet weak var myLabel: UILabel!
}


// I paid for this with grades in my last work 
let book1 = Book(); let book2 = Book(); let book3 = Book(); let book4 = Book(); let book5 = Book(); let book6 = Book(); let book7 = Book(); let book8 = Book(); let book9 = Book(); let book10 = Book(); let book11 = Book(); let book12 = Book(); let book13 = Book(); let book14 = Book(); let book15 = Book(); let book16 = Book();
var wasPressed = false
var numOfBooks = 0
var numOfAddedBooks = 0
var deleteNumCorrection = 0
var bookArr = [book1, book2, book3, book4, book5, book6, book7, book8, book9, book10, book11, book12, book13, book14, book15, book16]
var descIndex = 0
var searching = false
var filteredBookArr = [Book]()
var temp = [Book]()
var alerted = false
var beforeSearch = false
var canBeSelected = true


class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchResultsUpdating, UISearchBarDelegate  {
           
    @IBOutlet weak var tableView: UITableView!
            
    var addBookTitle: String?
    var addBookSubtitle: String?
    var addBookPrice: String?
    var justAdded: Bool?
    var resultSearchController = UISearchController()
    
    
    public func setAddedBook(title: String, subtitle: String, price: String){
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let filePath = Bundle.main.path(forResource: "BooksList", ofType: "txt")
        var text = ""
        text = try! String(contentsOfFile: filePath!)
        
        let tempArr = text.components(separatedBy: "{")
        
        if let add = justAdded {
            if add == true{
                numOfAddedBooks += 1
                justAdded = false
            }
        }
        numOfBooks = tempArr.count - 2 + numOfAddedBooks + deleteNumCorrection
        
        var textArr = text.components(separatedBy: CharacterSet(charactersIn: "[{\"]"))
        
        var iterator = 0
        while iterator < textArr.count{
            if textArr[iterator] == "" || textArr[iterator] == " "{
                textArr.remove(at: iterator)
                iterator -= 1
            }
            iterator += 1
        }
        textArr.remove(at: 0)
        textArr.remove(at: 0)
        textArr.remove(at: textArr.count-1)
        iterator = 0
                
        
        //Parsing through txt file and setting the entity properties right away
        func propertySetter(book: Book){
                if textArr[iterator] == "title"{
                    if textArr[iterator + 2] != ","{
                        book.title = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.title = "No title"; iterator += 3 }
                }
                if textArr[iterator] == "subtitle"{
                    if textArr[iterator + 2] != ","{
                        book.subtitle = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.subtitle = "No subtitle"; iterator += 3 }
                }
                if textArr[iterator] == "isbn13"{
                    if textArr[iterator + 2] != "," {
                        book.isbn13 = textArr[iterator + 2]
                        iterator += 4
                        
                        if textArr[iterator - 2] != "noid"{
                            let descPath = Bundle.main.path(forResource: book.isbn13, ofType: "txt")
                            var descText = ""
                            descText = try! String(contentsOfFile: descPath!)
                                                        
                            var descTextArr = descText.components(separatedBy: CharacterSet(charactersIn: "[{\"]"))
                                                        
                            var iter = 0
                            while iter < descTextArr.count{
                                if descTextArr[iter] == "" || descTextArr[iter] == " "{
                                    descTextArr.remove(at: iter)
                                    iter -= 1
                                }
                                iter += 1
                            }                            
                            iter = 0
                            if descTextArr[iter] == "title"{
                                if descTextArr[iter + 2] != ","{
                                    book.title = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.title = "No title"; iter += 3 }
                            }
                            if descTextArr[iter] == "subtitle"{
                                if descTextArr[iter + 2] != ","{
                                    book.subtitle = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.subtitle = "No subtitle"; iter += 3 }
                            }
                            if descTextArr[iter] == "authors"{
                                if descTextArr[iter + 2] != ","{
                                    book.authors = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.authors = "No authors"; iter += 3 }
                            }
                            if descTextArr[iter] == "publisher"{
                                if descTextArr[iter + 2] != ","{
                                    book.publisher = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.publisher = "No publisher"; iter += 3 }
                            }
                            iter += 4
                            if descTextArr[iter] == "pages"{
                                if descTextArr[iter + 2] != ","{
                                    book.pages = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.pages = "No pages given"; iter += 3 }
                            }
                            if descTextArr[iter] == "year"{
                                if descTextArr[iter + 2] != ","{
                                    book.year = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.year = "No year given"; iter += 3 }
                            }
                            if descTextArr[iter] == "rating"{
                                if descTextArr[iter + 2] != ","{
                                    book.rating = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.rating = "No rating"; iter += 3 }
                            }
                            if descTextArr[iter] == "desc"{
                                if descTextArr[iter + 2] != ","{
                                    book.desc = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.desc = "No description"; iter += 3 }
                            }
                            if descTextArr[iter] == "price"{
                                if descTextArr[iter + 2] != ","{
                                    book.price = descTextArr[iter + 2]
                                    iter += 4
                                }else{ book.price = "No price"; iter += 3 }
                            }
                            if descTextArr[iter] == "image"{
                                if descTextArr[iter + 2] != "}/n"{
                                    book.image = descTextArr[iter + 2]
                                }else{ book.image = "No image" }
                            }
                        }
                    }else{ book.isbn13 = "No isbn13"; iterator += 3 }
                }
                if textArr[iterator] == "price"{
                    if textArr[iterator + 2] != ","{
                        book.price = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.price = "No price"; iterator += 3 }
                }
                if textArr[iterator] == "image"{
                    if textArr[iterator + 2] != "},"{
                        book.image = textArr[iterator + 2]
                        iterator += 4
                    }else{ book.image = "No image"; iterator += 3 }
                }
        }
    
                
        var j = 0
        
        if numOfAddedBooks != 0 && addBookTitle != nil {
            bookArr[numOfBooks-1].title = addBookTitle!
            bookArr[numOfBooks-1].subtitle = addBookSubtitle!
            bookArr[numOfBooks-1].price = addBookPrice!
            bookArr[numOfBooks-1].image = "No image"
            bookArr[numOfBooks-1].added = true
        }else{
            while j < numOfBooks - numOfAddedBooks {
                propertySetter(book: bookArr[j])
                j += 1
            }
        }
        
                
        
        resultSearchController = ({
                let controller = UISearchController(searchResultsController: nil)
                controller.searchResultsUpdater = self
                controller.obscuresBackgroundDuringPresentation = false
                controller.searchBar.sizeToFit()
                controller.searchBar.enablesReturnKeyAutomatically = false
                controller.searchBar.returnKeyType = UIReturnKeyType.done
                definesPresentationContext = true
                tableView.tableHeaderView = controller.searchBar
                controller.searchBar.delegate = self            
                return controller
            })()
                                
                
        //TableView:
                
        tableView.dataSource = self
        tableView.delegate = self
        self.view.addSubview(tableView)
        self.tableView.rowHeight = UITableView.automaticDimension
        self.definesPresentationContext = true
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if alerted{
            return 1
        }else if resultSearchController.isActive{
            return filteredBookArr.count
        }else{
            return numOfBooks}
    }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (resultSearchController.isActive == false && bookArr[indexPath.row].image == "No image") || alerted || (resultSearchController.isActive && filteredBookArr[indexPath.row].image == "No image") {
            let MyCellNoIm = tableView.dequeueReusableCell(withIdentifier: "MyCellNoImageId", for: indexPath as IndexPath) as! MyCellNoImage
            if resultSearchController.isActive && beforeSearch == false {
                if alerted {
                    MyCellNoIm.myLabel!.text = "There is no such book in this list"
                    MyCellNoIm.myLabel!.numberOfLines = 10
                    alerted = false
                    canBeSelected = false
                    
                    return MyCellNoIm
                }else{
                if filteredBookArr[indexPath.row].subtitle != "No subtitle"{
                    MyCellNoIm.myLabel!.text = filteredBookArr[indexPath.row].title + "\n\n" + filteredBookArr[indexPath.row].subtitle + "\n\n" + filteredBookArr[indexPath.row].price
                }else{
                MyCellNoIm.myLabel!.text = filteredBookArr[indexPath.row].title + "\n\n" + filteredBookArr[indexPath.row].price
                }
                MyCellNoIm.myLabel!.font = MyCellNoIm.myLabel!.font.withSize(12.0)
                MyCellNoIm.myLabel!.lineBreakMode = NSLineBreakMode.byWordWrapping
                MyCellNoIm.myLabel!.numberOfLines = 10
                                
                return MyCellNoIm
                }
            }else{
                if bookArr[indexPath.row].subtitle != "No subtitle"{
                    MyCellNoIm.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].subtitle + "\n\n" + bookArr[indexPath.row].price
                }else{
                    MyCellNoIm.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].price
                }
                MyCellNoIm.myLabel!.font = MyCellNoIm.myLabel!.font.withSize(12.0)
                MyCellNoIm.myLabel!.lineBreakMode = NSLineBreakMode.byWordWrapping
                MyCellNoIm.myLabel!.numberOfLines = 10
                
                return MyCellNoIm
            }
        }else{
            let MyCell = tableView.dequeueReusableCell(withIdentifier: "MyCellId", for: indexPath as IndexPath) as! MyCell
            if resultSearchController.isActive && beforeSearch == false {
                
                if filteredBookArr[indexPath.row].subtitle != "No subtitle"{
                    MyCell.myLabel!.text = filteredBookArr[indexPath.row].title + "\n\n" + filteredBookArr[indexPath.row].subtitle + "\n\n" + filteredBookArr[indexPath.row].price
                }else{
                MyCell.myLabel!.text = filteredBookArr[indexPath.row].title + "\n\n" + filteredBookArr[indexPath.row].price
                }
                MyCell.myLabel!.font = MyCell.myLabel!.font.withSize(12.0)
                MyCell.myLabel!.lineBreakMode = NSLineBreakMode.byWordWrapping
                MyCell.myLabel!.numberOfLines = 10
                
                
                MyCell.myImage!.image = UIImage(named: filteredBookArr[indexPath.row].image)!
                MyCell.myImage!.heightAnchor.constraint(equalToConstant: 100.0).isActive = true
                MyCell.myImage!.widthAnchor.constraint(equalToConstant: 77.0).isActive = true
                
                return MyCell
                
            }else{
                if bookArr[indexPath.row].subtitle != "No subtitle"{
                    MyCell.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].subtitle + "\n\n" + bookArr[indexPath.row].price
                }else{
                    MyCell.myLabel!.text = bookArr[indexPath.row].title + "\n\n" + bookArr[indexPath.row].price
                }
                MyCell.myLabel!.font = MyCell.myLabel!.font.withSize(12.0)
                MyCell.myLabel!.lineBreakMode = NSLineBreakMode.byWordWrapping
                MyCell.myLabel!.numberOfLines = 10
                
                
                MyCell.myImage!.image = UIImage(named: bookArr[indexPath.row].image)!
                MyCell.myImage!.heightAnchor.constraint(equalToConstant: 100.0).isActive = true
                MyCell.myImage!.widthAnchor.constraint(equalToConstant: 77.0).isActive = true
            
                return MyCell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if resultSearchController.isActive == false{
            return true
        }else{ return false }
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if (editingStyle == .delete) {
            if bookArr[indexPath.row].added{
                numOfAddedBooks -= 1
                numOfBooks -= 1
            }else{ numOfBooks -= 1; deleteNumCorrection -= 1 }
            bookArr.remove(at: indexPath.row)
            let book = Book()
            bookArr.append(book)
                
            tableView.reloadData()
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if filteredBookArr.count != 0 { canBeSelected = true }
            if canBeSelected {
        searching = resultSearchController.isActive
        if filteredBookArr.count == 0{
            temp = bookArr
        }else{ temp = filteredBookArr }
            descIndex = indexPath.row
            performSegue(withIdentifier: "CellSegue", sender: self)
        }else{ return }
    }
        
    
    func updateSearchResults(for searchController: UISearchController) {
        filteredBookArr = bookArr.filter({ (book: Book) -> Bool in
            if searchController.searchBar.text != nil {
                return book.title.lowercased().contains(searchController.searchBar.text!.lowercased())
            } else { return false }
        })
        
        if filteredBookArr.count == 0{
            beforeSearch = true
        }else{ beforeSearch = false }

        if filteredBookArr.count == 0 && searchController.searchBar.text != "" && searchController.searchBar.text != nil{
            alerted = true
            beforeSearch = false
            tableView.reloadData()
        }
        
        if (searchController.searchBar.text != nil && searchController.searchBar.text != "") || searchController.isActive == false {
            tableView.reloadData()
        }
    }
    
}
