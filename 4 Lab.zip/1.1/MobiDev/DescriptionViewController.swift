//
//  DescriptionViewController.swift
//  MobiDev
//
//  Created by Cockerman on 07.05.2021.
//

import UIKit

class DescriptionViewController: UIViewController {
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var descImage: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if searching{
            descImage.image = UIImage(named: temp[descIndex].image)
            if temp[descIndex].desc != ""{
            descLabel.text = "Title: " + temp[descIndex].title + "\n\nSubtitle: " +  temp[descIndex].subtitle + "\n\nDescription: " + temp[descIndex].desc + "\n\n\nAuthors: " + temp[descIndex].authors + "\nPublisher:" + temp[descIndex].publisher + "\n\n\nYear: " + temp[descIndex].year + "\n\nPages:" + temp[descIndex].pages + "\nISBN13: " + temp[descIndex].isbn13 + "\nRating: " + temp[descIndex].rating + "\n\nPrice: " + temp[descIndex].price
            }else{
                descLabel.text = "Title: " + temp[descIndex].title + "\n\nSubtitle: " +  temp[descIndex].subtitle + "\n\nPrice: " + temp[descIndex].price
            }
            descLabel.font = descLabel.font.withSize(12.0)
            descLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
            descLabel.numberOfLines = 0
            
        }else{
            descImage.image = UIImage(named: bookArr[descIndex].image)
            if bookArr[descIndex].desc != ""{
            descLabel.text = "Title: " + bookArr[descIndex].title + "\n\nSubtitle: " +  bookArr[descIndex].subtitle + "\n\nDescription: " + bookArr[descIndex].desc + "\n\n\nAuthors: " + bookArr[descIndex].authors + "\nPublisher:" + bookArr[descIndex].publisher + "\n\n\nYear: " + bookArr[descIndex].year + "\n\nPages:" + bookArr[descIndex].pages + "\nISBN13: " + bookArr[descIndex].isbn13 + "\nRating: " + bookArr[descIndex].rating + "\n\nPrice: " + bookArr[descIndex].price
            }else{
                descLabel.text = "Title: " + bookArr[descIndex].title + "\n\nSubtitle: " +  bookArr[descIndex].subtitle + "\n\nPrice: " + bookArr[descIndex].price
            }
            descLabel.font = descLabel.font.withSize(12.0)
            descLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
            descLabel.numberOfLines = 0
        }
    }    

}
